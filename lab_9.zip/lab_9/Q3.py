#Lab9_Q3

def load_and_prepare_data(file_path):
    import pandas as pd
    
    dataset = pd.read_csv(file_path)
    
    if 'name' in dataset.columns:
        dataset = dataset.drop('name', axis=1)
    
    X = dataset.drop('status', axis=1)
    y = dataset['status']
    
    return X, y


def split_data(X, y):
    from sklearn.model_selection import train_test_split
    
    return train_test_split(X, y, test_size=0.2, random_state=42)


def build_pipeline():
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.ensemble import RandomForestClassifier

    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
    ])

    return pipeline


def explain_with_lime(model, X_train, X_test):
    import lime
    import lime.lime_tabular

    explainer = lime.lime_tabular.LimeTabularExplainer(
        training_data=X_train.values,
        feature_names=X_train.columns.tolist(),
        class_names=["Healthy", "Parkinson's"],
        mode='classification'
    )

    explanation = explainer.explain_instance(
        X_test.iloc[0].values,
        model.predict_proba
    )

    return explanation


# MAIN
X, y = load_and_prepare_data("parkinsons.csv")
X_train, X_test, y_train, y_test = split_data(X, y)

pipeline = build_pipeline()
pipeline.fit(X_train, y_train)

explanation = explain_with_lime(pipeline, X_train, X_test)

# Display explanation
explanation.show_in_notebook()