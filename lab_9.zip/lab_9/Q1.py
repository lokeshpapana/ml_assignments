#Lab_9_Q1

def load_and_prepare_data(file_path):
    import pandas as pd
    
    dataset = pd.read_csv(file_path)
    
    if 'name' in dataset.columns:
        dataset = dataset.drop('name', axis=1)
    
    X = dataset.drop('status', axis=1)
    y = dataset['status']
    
    return X, y


def split_data(X, y):
    from sklearn.model_selection import train_test_split
    
    return train_test_split(X, y, test_size=0.2, random_state=42)


def build_stacking_model():
    from sklearn.ensemble import StackingClassifier, RandomForestClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.svm import SVC
    from sklearn.neighbors import KNeighborsClassifier

    base_models = [
        ('rf', RandomForestClassifier(n_estimators=100, random_state=42)),
        ('svm', SVC(probability=True, random_state=42)),
        ('knn', KNeighborsClassifier(n_neighbors=5))
    ]

    meta_model = LogisticRegression()

    model = StackingClassifier(
        estimators=base_models,
        final_estimator=meta_model,
        cv=5
    )

    return model


# MAIN
X, y = load_and_prepare_data("parkinsons.csv")
X_train, X_test, y_train, y_test = split_data(X, y)

model = build_stacking_model()
model.fit(X_train, y_train)

accuracy = model.score(X_test, y_test)
print("Stacking Model Accuracy:", accuracy)