#Lab9_Q2

def load_and_prepare_data(file_path):
    import pandas as pd
    
    dataset = pd.read_csv(file_path)
    
    if 'name' in dataset.columns:
        dataset = dataset.drop('name', axis=1)
    
    X = dataset.drop('status', axis=1)
    y = dataset['status']
    
    return X, y


def split_data(X, y):
    from sklearn.model_selection import train_test_split
    
    return train_test_split(X, y, test_size=0.2, random_state=42)


def build_pipeline():
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.ensemble import RandomForestClassifier

    pipeline = Pipeline([
        ('scaler', StandardScaler()),
        ('classifier', RandomForestClassifier(n_estimators=100, random_state=42))
    ])

    return pipeline


# MAIN
X, y = load_and_prepare_data("parkinsons.csv")
X_train, X_test, y_train, y_test = split_data(X, y)

pipeline = build_pipeline()
pipeline.fit(X_train, y_train)

accuracy = pipeline.score(X_test, y_test)
print("Pipeline Model Accuracy:", accuracy)